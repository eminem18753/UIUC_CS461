import hashlib

result="'or'"
brute_force=300000000000000000000000000000000000000

while True:
	brute_force=brute_force+1
	m=hashlib.md5()
	m.update(str(brute_force))
	hashResult=m.digest()
	checkNumber=hashResult.lower().find(result);
	if(checkNumber>=0):
		if(hashResult[checkNumber+4].isdigit()):
			break
print brute_force
